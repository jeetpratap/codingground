package com.revature.service;

import com.revature.domain.Bid;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author gibbi3
 * 
 * CalculateWinnerImpl takes in an ArrayList made of Bids, and returns the winning Bid.
 * 
 * Winning Bid object returned will contain:
 * 	String bidder - the name of the person to whom the bid belongs
 *	double starting_bid - the initial value of the bid
 *	double current_bid - the current value of the bid. Initially, the constructor sets this to the value
 *						 of the starting_bid.
 *	double max_bid - The maximum amount bidder is willing to increment the current_bid
 *	double auto_increment - The value the current_bid will be incremented each increase
 */
public class CalculateWinnerImpl implements CalculateWinner {
	
	public Bid calculateWinner(ArrayList<Bid> bids) {
		
		// Initialization of variables applicable to the auction as a whole. 
		
		// Lead bid defaulted to 0.00
		double lead_bid = 0.00;
		// current_leader set to null
		Bid current_leader = null;
		// winner set to null and will remain so until end of auction.
		Bid winner = null;
		// nowBidding set to true, meaning the auction is in session. Setting to false will end the auction.
		boolean nowBidding = true;
		// A Set is used to note those who have reached their limit. Winner is added once Set is 1 short of total bidders.
		Set<String> done_bidding = new HashSet<String>();
		
		// Loop runs for the duration of bidding. Shuts off when all bidders are in Set done_bidding.
		while(nowBidding) {
			
			// Cycle through each Bid while nowBidding remains true.
			for(Bid b : bids) {
				
				// Extracting states of current Bid b
				double starting_bid = b.getStarting_bid();
				double current_bid = b.getCurrent_bid();
				double max_bid = b.getMax_bid();
				double auto_increment = b.getAuto_increment();
				
				// This affixes the starting_bid of the first bidder to the lead_bid at the very beginning of the auction.
				if(lead_bid == 0.00) {
					lead_bid = starting_bid;
					current_leader = b;
				}
				
				// A bid increase is continually initialized while Bid b is not the current_leader
				bid_increase: while(!current_leader.equals(b)) {
					
					// Bid is incremented by its auto_increment amount if the resulting sum is <= max_bid
					if((current_bid + auto_increment) <= max_bid) {
						current_bid += auto_increment;
						b.setCurrent_bid(current_bid);
						
						// Once bid takes the lead, Bid b is set to current_leader and lead_bid is set to b's current_bid
						// This will exit the bid_increase loop.
						if(b.getCurrent_bid() > lead_bid) {
							current_leader = b;
							lead_bid = b.getCurrent_bid();
						}
					
					// Once bid in danger of passing max_bid, bid_increase is discontinued
					}else{
						break bid_increase;
					}
				}
				
				// Check to see if Bid is unable to continue incrementing, or if Bid is the only one not in done_bidding
				if((max_bid < (lead_bid + auto_increment)) || (done_bidding.size() == (bids.size()-1))) {
					done_bidding.add(b.getBidder());
					
					// Once all bidders are done bidding, nowBidding loop is shut off.
					if(done_bidding.size() == bids.size()){
						nowBidding = false;
					}
				}
			}
		}
		
		// Winner is set to current_leader at the end of the auction.
		winner = current_leader;
		
		return winner;
		
	}

}
