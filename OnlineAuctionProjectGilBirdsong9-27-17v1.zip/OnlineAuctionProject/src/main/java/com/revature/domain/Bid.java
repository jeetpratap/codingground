package com.revature.domain;

import java.io.Serializable;

public class Bid implements Serializable{

	private static final long serialVersionUID = 981982400700004714L;
	
	private String bidder;
	private double starting_bid;
	private double current_bid = starting_bid;
	private double max_bid;
	private double auto_increment;
	
	public Bid() {}
	
	// current_bid initially set to same value as starting_bid
	public Bid(String bidder, double starting_bid, double max_bid, double auto_increment) {
		super();
		this.bidder = bidder;
		this.starting_bid = starting_bid;
		this.current_bid = starting_bid;
		this.max_bid = max_bid;
		this.auto_increment = auto_increment;
	}

	public String getBidder() {
		return bidder;
	}

	public void setBidder(String bidder) {
		this.bidder = bidder;
	}

	public double getStarting_bid() {
		return starting_bid;
	}

	public void setStarting_bid(double starting_bid) {
		this.starting_bid = starting_bid;
	}

	public double getMax_bid() {
		return max_bid;
	}

	public void setMax_bid(double max_bid) {
		this.max_bid = max_bid;
	}

	public double getAuto_increment() {
		return auto_increment;
	}

	public void setAuto_increment(double auto_increment) {
		this.auto_increment = auto_increment;
	}
	
	public double getCurrent_bid() {
		return current_bid;
	}

	public void setCurrent_bid(double current_bid) {
		this.current_bid = current_bid;
	}

	@Override
	public String toString() {
		return "Bid [bidder=" + bidder + ", starting_bid=" + starting_bid + ", current_bid=" + current_bid
				+ ", max_bid=" + max_bid + ", auto_increment=" + auto_increment + "]";
	}

}
