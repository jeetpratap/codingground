package com.revature.service;

import java.util.ArrayList;

import com.revature.domain.Bid;

public interface CalculateWinner {
	
	public Bid calculateWinner(ArrayList<Bid> bids);
	
}
