package com.revature;

import java.util.ArrayList;

import com.revature.domain.Bid;
import com.revature.service.CalculateWinner;
import com.revature.service.CalculateWinnerImpl;

public class Driver {
	
	static CalculateWinner calc = new CalculateWinnerImpl();

	public static void main(String[] args) {
		
		Auction1();
		Auction2();
		Auction3();

	}
	
	public static void Auction1() {
		
		ArrayList<Bid> bids = new ArrayList<Bid>();
		
		Bid bid1 = new Bid("Linda", 170.00, 240.00, 3.00);
		Bid bid2 = new Bid("Dave", 160.00, 243.00, 7.00);
		Bid bid3 = new Bid("Eric", 190.00, 240.00, 4.00);
		
		bids.add(bid1);
		bids.add(bid2);
		bids.add(bid3);
		
		Bid winner = calc.calculateWinner(bids);
		
		System.out.println("**********\nWinner is " + winner+"\n**********");
	}
	
	public static void Auction2() {
		
		ArrayList<Bid> bids = new ArrayList<Bid>();
		
		Bid bid1 = new Bid("Linda", 30.00, 70.00, 4.00);
		Bid bid2 = new Bid("Dave", 30.00, 70.00, 3.00);
		Bid bid3 = new Bid("Eric", 40.00, 90.00, 2.00);
		
		bids.add(bid1);
		bids.add(bid2);
		bids.add(bid3);
		
		Bid winner = calc.calculateWinner(bids);
		
		System.out.println("**********\nWinner is " + winner+"\n**********");
	}
	
	public static void Auction3() {
		
		ArrayList<Bid> bids = new ArrayList<Bid>();
		
		Bid bid1 = new Bid("Linda", 20_000.00, 65_000.00, 2000.00);
		Bid bid2 = new Bid("Dave", 10_000.00, 70_000.00, 15_000.00);
		Bid bid3 = new Bid("Eric", 22_000.00, 70_000.00, 8000.00);
		
		bids.add(bid1);
		bids.add(bid2);
		bids.add(bid3);
		
		Bid winner = calc.calculateWinner(bids);
		
		System.out.println("**********\nWinner is " + winner+"\n**********");
	}

}
