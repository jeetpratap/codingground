package test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.revature.domain.Bid;
import com.revature.service.CalculateWinner;
import com.revature.service.CalculateWinnerImpl;

public class OnlineAuctionTest {
	
	CalculateWinner calc = new CalculateWinnerImpl();
	
	@BeforeClass
	public static void before() {
		System.out.println("Commencing Tests");
	}

	@Test
	public void calculateWinnerTest1() {
		
		ArrayList<Bid> bids1 = new ArrayList<Bid>();
		
		Bid bid1_1 = new Bid("Linda", 170.00, 240.00, 3.00);
		Bid bid1_2 = new Bid("Dave", 160.00, 243.00, 7.00);
		Bid bid1_3 = new Bid("Eric", 190.00, 240.00, 4.00);
				
		bids1.add(bid1_1);
		bids1.add(bid1_2);
		bids1.add(bid1_3);

		assertEquals(bid1_1, calc.calculateWinner(bids1));
	}
	
	@Test
	public void calculateWinnerTest2() {
		
		ArrayList<Bid> bids2 = new ArrayList<Bid>();
		
		Bid bid2_1 = new Bid("Linda", 30.00, 70.00, 4.00);
		Bid bid2_2 = new Bid("Dave", 30.00, 70.00, 3.00);
		Bid bid2_3 = new Bid("Eric", 40.00, 90.00, 2.00);

		bids2.add(bid2_1);
		bids2.add(bid2_2);
		bids2.add(bid2_3);
		
		assertEquals(bid2_3, calc.calculateWinner(bids2));
		
	}
	
	@Test
	public void calculateWinnerTest3() {

		ArrayList<Bid> bids3 = new ArrayList<Bid>();
		
		Bid bid3_1 = new Bid("Linda", 20_000.00, 65_000.00, 2000.00);
		Bid bid3_2 = new Bid("Dave", 10_000.00, 70_000.00, 15_000.00);
		Bid bid3_3 = new Bid("Eric", 22_000.00, 70_000.00, 8000.00);

		bids3.add(bid3_1);
		bids3.add(bid3_2);
		bids3.add(bid3_3);
		
		assertEquals(bid3_2, calc.calculateWinner(bids3));
		
	}
	
	@Test
	public void edgeCaseTest() {
		
		ArrayList<Bid> bids4 = new ArrayList<Bid>();
		
		Bid bid3_1 = new Bid("Linda", 20_000.00, 65_000.00, 2000.00);
		Bid bid3_2 = new Bid("Dave", 10_000.00, 70_000.00, 15_000.00);
		Bid bid3_3 = new Bid("Eric", 22_000.00, 80_000.00, 8000.00);
		Bid bid3_4 = new Bid("Hannibal", 10_000.00, 70_000.00, 15_000.00);
		// Max bid set to lower than initial bid. Auto increment set to 10 x both combined.
		Bid bid3_5 = new Bid("Scipio", 10_000.00, 5000.00, 150_000.00);

		bids4.add(bid3_1);
		bids4.add(bid3_2);
		bids4.add(bid3_3);
		bids4.add(bid3_4);
		bids4.add(bid3_5);
		
		assertEquals(bid3_3, calc.calculateWinner(bids4));
		
	}
	
	@AfterClass
	public static void after() {
		System.out.println("Tests completed successfully.");
	}
	

}
